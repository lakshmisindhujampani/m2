package com.cg.tms.dao;

import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;

public interface TicketDAO {

	Map<String, String> getTicketCategoryEntries() throws TicketException;

	void addTicket(TicketBean ticketBean) throws TicketException;

}
