package com.cg.tms.dao;

import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO {

	@Override
	public Map<String, String> getTicketCategoryEntries()
			throws TicketException {
		return Util.getTicketCategoryEntries();
	}

	@Override
	public void addTicket(TicketBean ticketBean) throws TicketException {
		Util.addTicket(ticketBean);

	}

}
