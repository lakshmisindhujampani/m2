package com.cg.tms.test;

import static org.junit.Assert.assertFalse;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;

public class RaiseTicketTest {
	TicketBean ticketBean=new TicketBean();
	private static TicketDAO dao;
	@BeforeClass
	public static void createInstance(){
		dao=new TicketDAOImpl();
	}
	@Test(expected=TicketException.class)
	public void testTicketDetailsNegative() throws TicketException {
		ticketBean.setTicketDescription("abcdef");
		ticketBean.setTicketCategoryId("tc001");
		ticketBean.setTicketStatus("new");
		ticketBean.setTicketNo(1234);
		ticketBean.setTicketPriority("low");
		Assert.assertArrayEquals(bookTicket.put(ticketBean), ticketBean);
	}
	@Test(expected=TicketException.class)
	public void testTicketDetailsPositive() throws TicketException {
		ticketBean.setTicketDescription("abcdef");
		ticketBean.setTicketCategoryId("tc001");
		ticketBean.setTicketStatus("new");
		ticketBean.setTicketNo(1234);
		ticketBean.setTicketPriority("low");
		boolean result=dao.addTicket(ticketBean);
		Assert.assertTrue(result);
	}
	@Test(expected=TicketException.class)
	public void testTicketDetailsPriorityNegative() throws TicketException {
		ticketBean.setTicketDescription("abcdef");
		ticketBean.setTicketCategoryId("tc001");
		ticketBean.setTicketStatus("new");
		ticketBean.setTicketNo(1234);
		ticketBean.setTicketPriority("low999");
		boolean result=dao.addTicket(ticketBean);
		Assert.assertFalse(result);
	}
	@Test(expected=TicketException.class)
	public void testTicketDetailsPriorityPositive() throws TicketException {
		ticketBean.setTicketDescription("abcdef");
		ticketBean.setTicketCategoryId("tc001");
		ticketBean.setTicketStatus("new");
		ticketBean.setTicketNo(1234);
		ticketBean.setTicketPriority("low999");
		boolean result=dao.addTicket(ticketBean);
		Assert.assertTrue(result);
	}

}
