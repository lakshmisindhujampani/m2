package com.cg.tms.service;

import java.util.Map;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;

public class TicketServiceImpl implements TicketService {
	TicketDAO dao = new TicketDAOImpl();

	@Override
	public Map<String, String> getTicketCategoryEntries()
			throws TicketException {
		// TODO Auto-generated method stub
		return dao.getTicketCategoryEntries();
	}

	@Override
	public void addTicket(TicketBean ticketBean) throws TicketException {
		dao.addTicket(ticketBean);
	}

}
