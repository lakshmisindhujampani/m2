package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {

	public static void main(String[] args) throws TicketException {

		TicketService service = new TicketServiceImpl();

		Scanner scanner = new Scanner(System.in);
		try {
			while (true) {
				System.out.println("Welcome to ITIMD Help Desk");
				System.out.println("1.Raise a Ticket");
				System.out.println("2.Exit from the system");

				int ch = scanner.nextInt();
				switch (ch) {
				case 1:

					TicketBean ticketBean = new TicketBean();
					Map<String, String> transportdetails = service
							.getTicketCategoryEntries();
					System.out
							.println("Select Ticket Category from below List:");
					int count = 1;
					// Displaying values stored in static database using
					// entrySet
					for (Map.Entry<String, String> entrySet : transportdetails
							.entrySet()) {
						System.out.println(count + ". " + entrySet.getValue());
						count++;
					}
					System.out.println("Enter Option:");

					int choice = scanner.nextInt();
					int count1 = 1;
					for (Map.Entry<String, String> entrySet : transportdetails
							.entrySet()) {
						if (choice == count1) {

							ticketBean.getTicketCategoryId();
						}
						count1++;
					}
					// Asking client to enter description
					System.out.println("Enter Description related to issue:");
					scanner.nextLine();
					String ticketDescription = scanner.nextLine();
					ticketBean.setTicketDescription(ticketDescription);// setting
																		// ticket
																		// description
					System.out
							.println("Enter Priority (1.low 2.medium 3.high):");// Asking
																				// client
																				// to
																				// choose
																				// priority
					int whenChoice = scanner.nextInt();
					if (whenChoice == 1) {
						ticketBean.setTicketPriority("low");// setting priority
					}
					if (whenChoice == 2) {
						ticketBean.setTicketPriority("medium");// setting
																// priority
					}
					if (whenChoice == 3) {
						ticketBean.setTicketPriority("high");// setting priority
					}
					service.addTicket(ticketBean);
					int ticketNo = (int) (Math.random() * 10000);// generating
																	// ticketNo
																	// using
																	// math.random()
					ticketBean.setTicketNo(ticketNo);
					LocalDateTime ldt = LocalDateTime.now();
					DateTimeFormatter f = DateTimeFormatter
							.ofPattern("dd MMMM yyyy hh:mm a");
					System.out.println("Ticket Number " + ticketNo
							+ " logged successfully at " + ldt.format(f));
					break;
				case 2:
					System.out.println("Operation compleated successfully");
					System.exit(0);
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("Internal error occured try again later.");

		}

	}
}
