package com.cg.tms.exception;

public class TicketException extends Exception {
	public TicketException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
